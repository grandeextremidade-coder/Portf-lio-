import { useState } from "react";
import { Image as ImageIcon, X, ChevronLeft, ChevronRight } from "lucide-react";
import { galeria, type ItemGaleria } from "../data/barbearia";
import { SectionTitle } from "./SectionTitle";
import { useScrollReveal } from "../hooks/useScrollReveal";

function Thumb({
  item,
  onOpen,
}: {
  item: ItemGaleria;
  onOpen: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onOpen}
      aria-label={`Ampliar: ${item.legenda}`}
      className="reveal group relative flex aspect-square flex-col items-center justify-center gap-2 overflow-hidden rounded-md border border-white/10 bg-surface-raised transition-transform duration-200 hover:-translate-y-0.5 hover:border-crimson/40"
    >
      <ImageIcon className="h-7 w-7 text-crimson/80" aria-hidden="true" />
      <span className="px-3 text-center text-[12px] font-medium text-steel">
        {item.legenda}
      </span>
      <span className="absolute left-2 top-2 rounded-sm bg-ink/70 px-2 py-0.5 text-[10px] font-semibold tracking-wide text-steel">
        {item.categoria}
      </span>
    </button>
  );
}

export function Gallery() {
  const ref = useScrollReveal<HTMLElement>();
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const close = () => setActiveIndex(null);
  const prev = () =>
    setActiveIndex((i) => (i === null ? null : (i - 1 + galeria.length) % galeria.length));
  const next = () =>
    setActiveIndex((i) => (i === null ? null : (i + 1) % galeria.length));

  const active = activeIndex !== null ? galeria[activeIndex] : null;

  return (
    <section id="galeria" ref={ref} className="bg-ink py-20 lg:py-28">
      <div className="container-page flex flex-col gap-10">
        <SectionTitle
          title="Nosso trabalho"
          description="Galeria preparada para receber fotos reais do ambiente e dos cortes assim que forem disponibilizadas."
        />

        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-3">
          {galeria.map((item, index) => (
            <Thumb key={item.id} item={item} onOpen={() => setActiveIndex(index)} />
          ))}
        </div>
      </div>

      {active && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={active.legenda}
          className="fixed inset-0 z-[60] flex animate-fade-in items-center justify-center bg-ink/95 p-5"
          onClick={close}
        >
          <button
            type="button"
            aria-label="Fechar"
            onClick={close}
            className="absolute right-5 top-5 flex h-11 w-11 items-center justify-center rounded-full border border-white/15 text-bone"
          >
            <X className="h-5 w-5" />
          </button>

          <button
            type="button"
            aria-label="Anterior"
            onClick={(e) => {
              e.stopPropagation();
              prev();
            }}
            className="absolute left-3 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-white/15 text-bone sm:left-6"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>

          <div
            className="flex aspect-square w-full max-w-md flex-col items-center justify-center gap-3 rounded-md border border-white/10 bg-surface-raised"
            onClick={(e) => e.stopPropagation()}
          >
            <ImageIcon className="h-12 w-12 text-crimson" aria-hidden="true" />
            <span className="text-[15px] font-medium text-bone">{active.legenda}</span>
            <span className="text-[12px] text-steel/70">{active.categoria}</span>
          </div>

          <button
            type="button"
            aria-label="Próxima"
            onClick={(e) => {
              e.stopPropagation();
              next();
            }}
            className="absolute right-3 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-white/15 text-bone sm:right-6"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      )}
    </section>
  );
}
