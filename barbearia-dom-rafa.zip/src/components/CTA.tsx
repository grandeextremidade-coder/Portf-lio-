import { MessageCircle, Navigation } from "lucide-react";
import { linkGoogleMaps, linkWhatsApp } from "../data/barbearia";
import { useScrollReveal } from "../hooks/useScrollReveal";

export function CTA() {
  const ref = useScrollReveal<HTMLElement>();

  return (
    <section ref={ref} className="relative overflow-hidden bg-surface py-20 lg:py-24">
      <div className="pointer-events-none absolute inset-0 bg-radial-fade" aria-hidden="true" />
      <div className="container-page reveal relative flex flex-col items-center gap-6 text-center">
        <h2 className="max-w-[18ch] text-3xl font-semibold leading-tight text-bone sm:text-4xl">
          Seu próximo corte começa aqui.
        </h2>
        <p className="max-w-[48ch] text-[15px] leading-relaxed text-steel">
          Entre em contato com a Barbearia Dom Rafa e consulte os horários e
          serviços disponíveis.
        </p>
        <div className="flex flex-col gap-3.5 sm:flex-row">
          <a
            href={linkWhatsApp()}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary"
          >
            <MessageCircle className="h-5 w-5" aria-hidden="true" />
            Falar pelo WhatsApp
          </a>
          <a
            href={linkGoogleMaps()}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-outline"
          >
            <Navigation className="h-5 w-5" aria-hidden="true" />
            Como chegar
          </a>
        </div>
      </div>
    </section>
  );
}
