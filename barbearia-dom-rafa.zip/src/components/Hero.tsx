import { MessageCircle, Star, MapPin, Scissors } from "lucide-react";
import { barbearia, linkWhatsApp } from "../data/barbearia";
import { useScrollReveal } from "../hooks/useScrollReveal";

export function Hero() {
  const ref = useScrollReveal<HTMLElement>();

  return (
    <section
      id="inicio"
      ref={ref}
      className="relative overflow-hidden bg-ink pb-20 pt-32 sm:pt-40 lg:pb-28 lg:pt-44"
    >
      <div className="pointer-events-none absolute inset-0 bg-radial-fade" aria-hidden="true" />

      <div className="container-page relative grid gap-14 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:gap-10">
        <div className="reveal flex flex-col items-start gap-7">
          <span className="eyebrow rounded-full border border-crimson/30 bg-crimson/10 px-3 py-1 text-[12px]">
            {barbearia.cidade} — {barbearia.estado}
          </span>

          <h1 className="max-w-[14ch] text-[42px] font-semibold leading-[1.05] tracking-tightest text-bone sm:text-[54px] lg:text-[60px]">
            {barbearia.textos.heroHeadline}
          </h1>

          <p className="max-w-[46ch] text-[16px] leading-relaxed text-steel sm:text-[17px]">
            {barbearia.textos.heroSubtitulo}
          </p>

          <div className="flex w-full flex-col gap-3.5 sm:w-auto sm:flex-row">
            <a
              href={linkWhatsApp()}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary"
            >
              <MessageCircle className="h-5 w-5" aria-hidden="true" />
              Agendar pelo WhatsApp
            </a>
            <a href="#sobre" className="btn-outline">
              Conhecer a barbearia
            </a>
          </div>

          <div className="mt-2 flex flex-wrap items-center gap-x-6 gap-y-3 border-t border-white/10 pt-6">
            <div className="flex items-center gap-2">
              <div className="flex" aria-hidden="true">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-crimson text-crimson" />
                ))}
              </div>
              <span className="text-[13px] text-steel">
                {barbearia.avaliacao.nota.toFixed(1)} · {barbearia.avaliacao.fonte.toLowerCase()}
                {" "}
                ({barbearia.avaliacao.totalAvaliacoes} avaliações)
              </span>
            </div>
            <div className="flex items-center gap-2 text-[13px] text-steel">
              <MapPin className="h-4 w-4 text-crimson" aria-hidden="true" />
              {barbearia.cidade} — {barbearia.estado}
            </div>
          </div>
        </div>

        <div className="reveal relative mx-auto w-full max-w-[440px] lg:mx-0 lg:ml-auto">
          <div className="absolute -inset-4 -z-10 rounded-lg bg-crimson/20 blur-3xl" aria-hidden="true" />
          <div className="relative flex aspect-[4/5] w-full flex-col items-center justify-center gap-4 rounded-lg border border-white/10 bg-surface-raised shadow-card">
            <Scissors className="h-10 w-10 text-crimson" aria-hidden="true" />
            <span className="text-[13px] font-medium tracking-wide text-steel">
              Foto da barbearia
            </span>
            <span className="text-[11px] text-steel/60">
              Espaço reservado para imagem oficial
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
