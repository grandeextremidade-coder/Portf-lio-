import { useState, type FormEvent } from "react";
import { Send } from "lucide-react";
import { barbearia } from "../data/barbearia";
import { SectionTitle } from "./SectionTitle";
import { useScrollReveal } from "../hooks/useScrollReveal";

export function Contact() {
  const ref = useScrollReveal<HTMLElement>();
  const [nome, setNome] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [servico, setServico] = useState("");
  const [mensagem, setMensagem] = useState("");

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();

    const linhas = [
      "Olá! Vim pelo site da Barbearia Dom Rafa.",
      nome && `Nome: ${nome}`,
      whatsapp && `Meu WhatsApp: ${whatsapp}`,
      servico && `Serviço de interesse: ${servico}`,
      mensagem && `Mensagem: ${mensagem}`,
    ].filter(Boolean);

    const texto = encodeURIComponent(linhas.join("\n"));
    window.open(
      `https://wa.me/${barbearia.contato.whatsappNumero}?text=${texto}`,
      "_blank",
      "noopener,noreferrer"
    );
  }

  return (
    <section id="contato" ref={ref} className="bg-ink py-20 lg:py-28">
      <div className="container-page grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
        <div className="flex flex-col gap-6">
          <SectionTitle
            title="Fale com a gente"
            description="Preencha o formulário e envie sua mensagem diretamente para o WhatsApp da Barbearia Dom Rafa."
          />
          <div className="flex flex-col gap-1 text-[15px] text-steel">
            <span className="font-semibold text-bone">Telefone / WhatsApp</span>
            <span>{barbearia.contato.telefoneExibicao}</span>
          </div>
        </div>

        <form
          onSubmit={handleSubmit}
          className="reveal flex flex-col gap-4 rounded-md border border-white/10 bg-surface-raised p-6 sm:p-8"
        >
          <div className="flex flex-col gap-1.5">
            <label htmlFor="nome" className="text-[13px] font-medium text-steel">
              Nome
            </label>
            <input
              id="nome"
              name="nome"
              type="text"
              required
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              className="rounded-sm border border-white/15 bg-ink px-4 py-3 text-[15px] text-bone outline-none transition-colors focus:border-crimson"
              placeholder="Seu nome"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="whatsapp" className="text-[13px] font-medium text-steel">
              WhatsApp
            </label>
            <input
              id="whatsapp"
              name="whatsapp"
              type="tel"
              required
              value={whatsapp}
              onChange={(e) => setWhatsapp(e.target.value)}
              className="rounded-sm border border-white/15 bg-ink px-4 py-3 text-[15px] text-bone outline-none transition-colors focus:border-crimson"
              placeholder="(62) 90000-0000"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="servico" className="text-[13px] font-medium text-steel">
              Serviço de interesse
            </label>
            <input
              id="servico"
              name="servico"
              type="text"
              value={servico}
              onChange={(e) => setServico(e.target.value)}
              className="rounded-sm border border-white/15 bg-ink px-4 py-3 text-[15px] text-bone outline-none transition-colors focus:border-crimson"
              placeholder="Ex: corte, barba..."
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="mensagem" className="text-[13px] font-medium text-steel">
              Mensagem
            </label>
            <textarea
              id="mensagem"
              name="mensagem"
              rows={4}
              value={mensagem}
              onChange={(e) => setMensagem(e.target.value)}
              className="resize-none rounded-sm border border-white/15 bg-ink px-4 py-3 text-[15px] text-bone outline-none transition-colors focus:border-crimson"
              placeholder="Como podemos ajudar?"
            />
          </div>

          <button type="submit" className="btn-primary mt-2 w-full">
            <Send className="h-5 w-5" aria-hidden="true" />
            Enviar pelo WhatsApp
          </button>
        </form>
      </div>
    </section>
  );
}
