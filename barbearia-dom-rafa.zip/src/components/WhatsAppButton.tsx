import { MessageCircle } from "lucide-react";
import { linkWhatsApp } from "../data/barbearia";

/**
 * Botão flutuante de WhatsApp, fixo no canto inferior da tela.
 * Discreto, mas sempre acessível durante a navegação no celular.
 */
export function WhatsAppFloatingButton() {
  return (
    <a
      href={linkWhatsApp()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Falar com a Barbearia Dom Rafa pelo WhatsApp"
      className="fixed bottom-5 right-5 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-crimson text-white shadow-[0_10px_30px_-8px_rgba(193,18,31,0.7)] transition-transform duration-200 hover:scale-105 active:scale-95 sm:h-16 sm:w-16"
    >
      <MessageCircle className="h-7 w-7" strokeWidth={2} aria-hidden="true" />
    </a>
  );
}
