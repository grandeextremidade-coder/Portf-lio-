import { MessageCircle } from "lucide-react";
import { linkWhatsApp, servicos } from "../data/barbearia";
import { SectionTitle } from "./SectionTitle";
import { ServiceCard } from "./ServiceCard";
import { useScrollReveal } from "../hooks/useScrollReveal";

export function Services() {
  const ref = useScrollReveal<HTMLElement>();

  return (
    <section id="servicos" ref={ref} className="bg-surface py-20 lg:py-28">
      <div className="container-page flex flex-col gap-10">
        <SectionTitle
          title="Nossos serviços"
          description="Serviços da Barbearia Dom Rafa."
        />

        {servicos.length > 0 ? (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {servicos.map((servico) => (
              <ServiceCard key={servico.id} servico={servico} />
            ))}
          </div>
        ) : (
          <div className="reveal flex flex-col items-start gap-5 rounded-md border border-white/10 bg-surface-raised p-8 sm:p-10">
            <p className="max-w-[52ch] text-[15px] leading-relaxed text-steel">
              Consulte a disponibilidade e os serviços oferecidos diretamente
              com a equipe da Barbearia Dom Rafa.
            </p>
            <a
              href={linkWhatsApp(
                "Olá! Gostaria de saber quais serviços a Barbearia Dom Rafa oferece."
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary"
            >
              <MessageCircle className="h-5 w-5" aria-hidden="true" />
              Consultar pelo WhatsApp
            </a>
          </div>
        )}
      </div>
    </section>
  );
}
