import { useEffect, useState } from "react";
import { Menu, X, MessageCircle } from "lucide-react";
import { linkWhatsApp } from "../data/barbearia";

const LINKS = [
  { href: "#inicio", label: "Início" },
  { href: "#sobre", label: "Sobre" },
  { href: "#servicos", label: "Serviços" },
  { href: "#galeria", label: "Galeria" },
  { href: "#horarios", label: "Horários" },
  { href: "#localizacao", label: "Localização" },
  { href: "#contato", label: "Contato" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-colors duration-300 ${
        scrolled || open
          ? "bg-ink/95 backdrop-blur border-b border-white/10"
          : "bg-gradient-to-b from-ink/80 to-transparent"
      }`}
    >
      <nav className="container-page flex h-[72px] items-center justify-between">
        <a href="#inicio" className="flex flex-col leading-none" onClick={() => setOpen(false)}>
          <span className="font-display text-xl font-semibold tracking-tight text-bone">
            Dom Rafa
          </span>
          <span className="text-[10px] font-semibold tracking-[0.2em] text-crimson">
            BARBEARIA
          </span>
        </a>

        <ul className="hidden items-center gap-8 lg:flex">
          {LINKS.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="text-[14px] font-medium text-steel transition-colors duration-200 hover:text-bone"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <a
          href={linkWhatsApp()}
          target="_blank"
          rel="noopener noreferrer"
          className="hidden items-center gap-2 rounded-sm bg-crimson px-5 py-2.5 text-[14px] font-semibold text-white transition-colors duration-200 hover:bg-crimson-dark lg:inline-flex"
        >
          <MessageCircle className="h-4 w-4" aria-hidden="true" />
          Agendar pelo WhatsApp
        </a>

        <button
          type="button"
          aria-label={open ? "Fechar menu" : "Abrir menu"}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
          className="flex h-11 w-11 items-center justify-center rounded-sm text-bone lg:hidden"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {open && (
        <div className="border-t border-white/10 bg-ink px-5 pb-8 pt-2 lg:hidden">
          <ul className="flex flex-col divide-y divide-white/10">
            {LINKS.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="block py-4 text-[16px] font-medium text-bone"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
          <a
            href={linkWhatsApp()}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => setOpen(false)}
            className="btn-primary mt-6 w-full"
          >
            <MessageCircle className="h-5 w-5" aria-hidden="true" />
            Agendar pelo WhatsApp
          </a>
        </div>
      )}
    </header>
  );
}
