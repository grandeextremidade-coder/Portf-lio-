import { Clock } from "lucide-react";
import type { Servico } from "../data/barbearia";
import { linkWhatsApp } from "../data/barbearia";

export function ServiceCard({ servico }: { servico: Servico }) {
  return (
    <div className="reveal flex flex-col gap-4 rounded-md border border-white/10 bg-surface-raised p-6 shadow-card transition-colors duration-200 hover:border-crimson/40">
      <div className="flex items-start justify-between gap-3">
        <h3 className="text-lg font-semibold text-bone">{servico.nome}</h3>
        <span className="whitespace-nowrap text-[15px] font-semibold text-crimson">
          {servico.preco}
        </span>
      </div>
      <p className="text-[14px] leading-relaxed text-steel">{servico.descricao}</p>
      <div className="mt-auto flex items-center justify-between gap-3 border-t border-white/10 pt-4">
        <span className="flex items-center gap-1.5 text-[13px] text-steel">
          <Clock className="h-4 w-4" aria-hidden="true" />
          {servico.duracao}
        </span>
        <a
          href={linkWhatsApp(
            `Olá! Gostaria de agendar o serviço "${servico.nome}" na Barbearia Dom Rafa.`
          )}
          target="_blank"
          rel="noopener noreferrer"
          className="text-[13px] font-semibold text-crimson hover:text-crimson-dark"
        >
          Agendar
        </a>
      </div>
    </div>
  );
}
