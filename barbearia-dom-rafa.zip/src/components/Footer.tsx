import { MessageCircle, Phone, MapPin } from "lucide-react";
import { barbearia, linkWhatsApp } from "../data/barbearia";

const LINKS = [
  { href: "#inicio", label: "Início" },
  { href: "#sobre", label: "Sobre" },
  { href: "#servicos", label: "Serviços" },
  { href: "#galeria", label: "Galeria" },
  { href: "#horarios", label: "Horários" },
  { href: "#localizacao", label: "Localização" },
];

export function Footer() {
  return (
    <footer className="border-t border-white/10 bg-ink pb-28 pt-14 sm:pb-14">
      <div className="container-page grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
        <div className="flex flex-col gap-3">
          <span className="font-display text-xl font-semibold text-bone">
            Barbearia Dom Rafa
          </span>
          <p className="text-[14px] text-steel">
            Barbearia em {barbearia.cidade} — {barbearia.estado}
          </p>
        </div>

        <div className="flex flex-col gap-3 text-[14px] text-steel">
          <span className="flex items-start gap-2">
            <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-crimson" aria-hidden="true" />
            {barbearia.endereco.logradouro} — {barbearia.endereco.bairro}
            <br />
            {barbearia.endereco.cidade} — {barbearia.endereco.estado}
          </span>
          <span className="flex items-center gap-2">
            <Phone className="h-4 w-4 shrink-0 text-crimson" aria-hidden="true" />
            {barbearia.contato.telefoneExibicao}
          </span>
        </div>

        <div className="flex flex-col gap-3">
          <nav aria-label="Links do rodapé" className="flex flex-col gap-2 text-[14px] text-steel">
            {LINKS.map((link) => (
              <a key={link.href} href={link.href} className="w-fit hover:text-bone">
                {link.label}
              </a>
            ))}
            <a
              href={linkWhatsApp()}
              target="_blank"
              rel="noopener noreferrer"
              className="flex w-fit items-center gap-1.5 hover:text-bone"
            >
              <MessageCircle className="h-4 w-4" aria-hidden="true" />
              WhatsApp
            </a>
          </nav>
        </div>
      </div>

      <div className="container-page mt-10 border-t border-white/10 pt-6">
        <p className="text-[12px] text-steel/70">
          © 2026 Barbearia Dom Rafa. Todos os direitos reservados.
        </p>
      </div>
    </footer>
  );
}
