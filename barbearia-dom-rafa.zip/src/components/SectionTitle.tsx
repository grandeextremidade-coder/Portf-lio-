type SectionTitleProps = {
  title: string;
  align?: "left" | "center";
  description?: string;
};

export function SectionTitle({
  title,
  align = "left",
  description,
}: SectionTitleProps) {
  const alignment = align === "center" ? "text-center items-center" : "text-left items-start";

  return (
    <div className={`reveal flex flex-col gap-3 ${alignment}`}>
      <h2 className="text-3xl font-semibold leading-[1.1] text-bone sm:text-4xl">
        {title}
      </h2>
      {description && (
        <p className="max-w-[52ch] text-[15px] leading-relaxed text-steel">
          {description}
        </p>
      )}
      <span className="mt-1 h-[3px] w-12 rounded-full bg-crimson" />
    </div>
  );
}
