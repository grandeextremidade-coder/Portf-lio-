import { MessageCircle, Image as ImageIcon } from "lucide-react";
import { barbearia, linkWhatsApp } from "../data/barbearia";
import { SectionTitle } from "./SectionTitle";
import { useScrollReveal } from "../hooks/useScrollReveal";

export function About() {
  const ref = useScrollReveal<HTMLElement>();

  return (
    <section id="sobre" ref={ref} className="bg-ink py-20 lg:py-28">
      <div className="container-page grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-center lg:gap-16">
        <div className="reveal order-2 flex aspect-[4/3] flex-col items-center justify-center gap-3 rounded-lg border border-white/10 bg-surface-raised lg:order-1">
          <ImageIcon className="h-9 w-9 text-crimson" aria-hidden="true" />
          <span className="text-[13px] font-medium text-steel">Foto do ambiente</span>
          <span className="text-[11px] text-steel/60">Espaço reservado para imagem oficial</span>
        </div>

        <div className="order-1 flex flex-col gap-6 lg:order-2">
          <SectionTitle title="Conheça a Dom Rafa" />

          <p className="max-w-[56ch] text-[15px] leading-relaxed text-steel sm:text-[16px]">
            {barbearia.textos.sobre}
          </p>

          <div className="reveal rounded-md border border-dashed border-white/15 bg-surface/60 p-5">
            <p className="text-[13px] leading-relaxed text-steel/80">
              Espaço reservado para futuras informações — história da
              barbearia, equipe, diferenciais e fotos do espaço serão
              adicionados aqui assim que forem confirmados pela Dom Rafa.
            </p>
          </div>

          <a
            href={linkWhatsApp("Olá! Gostaria de saber mais sobre a Barbearia Dom Rafa.")}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-outline w-fit"
          >
            <MessageCircle className="h-5 w-5" aria-hidden="true" />
            Falar com a barbearia
          </a>
        </div>
      </div>
    </section>
  );
}
