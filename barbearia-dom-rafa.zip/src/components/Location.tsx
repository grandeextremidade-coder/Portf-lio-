import { MapPin, Navigation } from "lucide-react";
import { barbearia, linkGoogleMaps } from "../data/barbearia";
import { SectionTitle } from "./SectionTitle";
import { useScrollReveal } from "../hooks/useScrollReveal";

export function Location() {
  const ref = useScrollReveal<HTMLElement>();
  const enderecoQuery = encodeURIComponent(barbearia.endereco.enderecoCompleto);

  return (
    <section id="localizacao" ref={ref} className="bg-ink py-20 lg:py-28">
      <div className="container-page grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:items-stretch lg:gap-16">
        <div className="flex flex-col gap-6">
          <SectionTitle title="Onde estamos" />

          <div className="flex items-start gap-3">
            <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-crimson" aria-hidden="true" />
            <address className="not-italic text-[15px] leading-relaxed text-steel">
              <strong className="block font-semibold text-bone">
                {barbearia.nomeCompleto}
              </strong>
              {barbearia.endereco.logradouro}
              <br />
              {barbearia.endereco.bairro}
              <br />
              {barbearia.endereco.cidade} — {barbearia.endereco.estado}
              <br />
              CEP {barbearia.endereco.cep}
            </address>
          </div>

          <div className="flex flex-col gap-3.5 sm:flex-row">
            <a
              href={linkGoogleMaps()}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary"
            >
              <Navigation className="h-5 w-5" aria-hidden="true" />
              Como chegar
            </a>
            <a
              href={linkGoogleMaps()}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-outline"
            >
              Abrir no Google Maps
            </a>
          </div>
        </div>

        <div className="reveal min-h-[320px] overflow-hidden rounded-md border border-white/10 lg:min-h-[420px]">
          <iframe
            title="Localização da Barbearia Dom Rafa no Google Maps"
            src={`https://www.google.com/maps?q=${enderecoQuery}&output=embed`}
            width="100%"
            height="100%"
            style={{ border: 0, minHeight: 320, filter: "grayscale(0.4) contrast(1.1)" }}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </section>
  );
}
