import { useEffect, useState } from "react";
import { Clock } from "lucide-react";
import { barbearia } from "../data/barbearia";
import { SectionTitle } from "./SectionTitle";
import { useScrollReveal } from "../hooks/useScrollReveal";

const DIAS_SEMANA = [
  "Domingo",
  "Segunda-feira",
  "Terça-feira",
  "Quarta-feira",
  "Quinta-feira",
  "Sexta-feira",
  "Sábado",
];

function minutosDoDia(date: Date) {
  return date.getHours() * 60 + date.getMinutes();
}

function paraMinutos(horario: string) {
  const [h, m] = horario.split(":").map(Number);
  return h * 60 + m;
}

export function OpeningHours() {
  const ref = useScrollReveal<HTMLElement>();
  const [agora, setAgora] = useState<Date | null>(null);

  useEffect(() => {
    setAgora(new Date());
    const id = setInterval(() => setAgora(new Date()), 60_000);
    return () => clearInterval(id);
  }, []);

  const diaAtual = agora ? DIAS_SEMANA[agora.getDay()] : null;

  return (
    <section id="horarios" ref={ref} className="bg-surface py-20 lg:py-28">
      <div className="container-page flex flex-col gap-10">
        <SectionTitle title="Horário de funcionamento" />

        <div className="reveal overflow-hidden rounded-md border border-white/10 bg-surface-raised">
          {barbearia.horarios.map((item, index) => {
            const isToday = diaAtual === item.dia;
            const temHorario = item.abertura && item.fechamento;

            let status: string | null = null;
            if (isToday && temHorario && agora) {
              const min = minutosDoDia(agora);
              const aberto =
                min >= paraMinutos(item.abertura as string) &&
                min < paraMinutos(item.fechamento as string);
              status = aberto ? "Aberto agora" : "Fechado agora";
            }

            return (
              <div
                key={item.dia}
                className={`flex items-center justify-between gap-4 px-5 py-4 sm:px-8 ${
                  index !== barbearia.horarios.length - 1 ? "border-b border-white/10" : ""
                } ${isToday ? "bg-crimson/10" : ""}`}
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`text-[14px] font-semibold sm:text-[15px] ${
                      isToday ? "text-bone" : "text-steel"
                    }`}
                  >
                    {item.dia}
                  </span>
                  {isToday && (
                    <span className="rounded-full bg-crimson px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-white">
                      Hoje
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-3 text-right">
                  {status && (
                    <span
                      className={`text-[12px] font-semibold ${
                        status === "Aberto agora" ? "text-green-400" : "text-steel"
                      }`}
                    >
                      {status}
                    </span>
                  )}
                  <span className="flex items-center gap-1.5 text-[14px] text-bone sm:text-[15px]">
                    <Clock className="h-4 w-4 text-crimson" aria-hidden="true" />
                    {temHorario ? `${item.abertura} — ${item.fechamento}` : "Não informado"}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
