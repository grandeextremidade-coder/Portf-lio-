import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { About } from "./components/About";
import { Services } from "./components/Services";
import { Gallery } from "./components/Gallery";
import { OpeningHours } from "./components/OpeningHours";
import { Location } from "./components/Location";
import { CTA } from "./components/CTA";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";
import { WhatsAppFloatingButton } from "./components/WhatsAppButton";

function App() {
  return (
    <>
      <a
        href="#inicio"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-sm focus:bg-crimson focus:px-4 focus:py-2 focus:text-white"
      >
        Pular para o conteúdo
      </a>
      <Navbar />
      <main>
        <Hero />
        <About />
        <Services />
        <Gallery />
        <OpeningHours />
        <Location />
        <CTA />
        <Contact />
      </main>
      <Footer />
      <WhatsAppFloatingButton />
    </>
  );
}

export default App;
