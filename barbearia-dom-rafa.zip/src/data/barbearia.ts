/**
 * ARQUIVO DE CONFIGURAÇÃO — BARBEARIA DOM RAFA
 * ---------------------------------------------
 * Todas as informações exibidas no site vêm deste arquivo.
 * Para atualizar o site, basta editar os valores abaixo.
 *
 * Campos marcados como "Informação a adicionar" ainda não foram
 * confirmados publicamente e devem ser preenchidos pelo proprietário
 * antes da publicação final, se desejado.
 */

export const barbearia = {
  nome: "Dom Rafa",
  nomeCompleto: "Barbearia Dom Rafa",
  categoria: "Barbearia",
  cidade: "São Miguel do Araguaia",
  estado: "GO",

  endereco: {
    logradouro: "Rua 8 B",
    bairro: "Setor Centro",
    cidade: "São Miguel do Araguaia",
    estado: "GO",
    cep: "76590-000",
    enderecoCompleto:
      "Rua 8 B, Setor Centro, São Miguel do Araguaia - GO, 76590-000",
  },

  contato: {
    telefoneExibicao: "(62) 99985-9558",
    whatsappNumero: "5562999859558", // formato internacional, sem espaços ou símbolos
  },

  avaliacao: {
    nota: 5.0,
    totalAvaliacoes: 196,
    fonte: "Avaliação pública encontrada",
  },

  // Não informado publicamente — não exibir como "aberto" sem confirmação
  horarios: [
    { dia: "Segunda-feira", abertura: "09:00", fechamento: "20:00" },
    { dia: "Terça-feira", abertura: "08:30", fechamento: "18:00" },
    { dia: "Quarta-feira", abertura: "08:30", fechamento: "18:00" },
    { dia: "Quinta-feira", abertura: "08:30", fechamento: "18:00" },
    { dia: "Sexta-feira", abertura: "08:30", fechamento: "18:00" },
    { dia: "Sábado", abertura: "09:00", fechamento: "19:00" },
    { dia: "Domingo", abertura: null, fechamento: null }, // Não informado
  ],

  redesSociais: {
    // Nenhuma rede social confirmada publicamente até o momento.
    instagram: null as string | null,
    facebook: null as string | null,
  },

  textos: {
    heroHeadline: "Mais que um corte. Seu estilo.",
    heroSubtitulo:
      "Conheça a Barbearia Dom Rafa em São Miguel do Araguaia e encontre um espaço preparado para cuidar do seu estilo.",
    sobre:
      "A Barbearia Dom Rafa está localizada no centro de São Miguel do Araguaia — GO e oferece um espaço dedicado aos cuidados com o visual masculino.",
    mensagemWhatsappPadrao:
      "Olá! Vim pelo site da Barbearia Dom Rafa e gostaria de saber mais sobre os serviços e horários disponíveis.",
  },

  // Nenhuma informação jurídica (CNPJ, razão social) foi confirmada publicamente.
  cnpj: null as string | null,
};

/**
 * SERVIÇOS
 * ---------
 * Não há uma lista pública confiável de serviços e preços da Dom Rafa.
 * Este array está vazio de propósito — quando o proprietário confirmar
 * os serviços oferecidos, adicione cada um seguindo o modelo comentado
 * abaixo. Enquanto estiver vazio, o site exibe uma chamada para consultar
 * a equipe diretamente pelo WhatsApp.
 *
 * Exemplo de preenchimento futuro:
 * {
 *   id: "corte",
 *   nome: "Corte",
 *   descricao: "Descrição curta do serviço.",
 *   preco: "A partir de R$ 00",
 *   duracao: "30 min",
 * }
 */
export type Servico = {
  id: string;
  nome: string;
  descricao: string;
  preco: string;
  duracao: string;
};

export const servicos: Servico[] = [];

/**
 * GALERIA
 * --------
 * Nenhuma foto oficial da Dom Rafa foi fornecida até o momento.
 * Os itens abaixo são placeholders identificados como tal — substitua
 * o campo "imagem" por fotos reais quando estiverem disponíveis.
 */
export type ItemGaleria = {
  id: string;
  legenda: string;
  categoria: "Ambiente" | "Corte";
};

export const galeria: ItemGaleria[] = [
  { id: "g1", legenda: "Foto do ambiente", categoria: "Ambiente" },
  { id: "g2", legenda: "Foto de corte", categoria: "Corte" },
  { id: "g3", legenda: "Foto do ambiente", categoria: "Ambiente" },
  { id: "g4", legenda: "Foto de corte", categoria: "Corte" },
  { id: "g5", legenda: "Foto do ambiente", categoria: "Ambiente" },
  { id: "g6", legenda: "Foto de corte", categoria: "Corte" },
];

export function linkWhatsApp(mensagem?: string): string {
  const texto = encodeURIComponent(
    mensagem ?? barbearia.textos.mensagemWhatsappPadrao
  );
  return `https://wa.me/${barbearia.contato.whatsappNumero}?text=${texto}`;
}

export function linkGoogleMaps(): string {
  const query = encodeURIComponent(barbearia.endereco.enderecoCompleto);
  return `https://www.google.com/maps/search/?api=1&query=${query}`;
}
